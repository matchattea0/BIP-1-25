﻿using System;
using System.Collections.Generic;
using System.Text;

namespace enginlab1
{
	class Program
	{
		static void Main(string[] args)
	    {
			System.Console.WriteLine("Лабораторна робота №1");
	        System.Console.WriteLine("Виконав студент групи <БІП-1-25> <Соловьян Дмитро Сергіойвич>");
	        System.Console.ReadKey();
	    }
    }
}

﻿using System;
Console.WriteLine("Input array size");
int n = int.Parse(Console.ReadLine());
Console.WriteLine("Input array");
int[] arr = Console.ReadLine().Split().Select(int.Parse).ToArray();
for (int i = 0; i < arr.Length; i++)
{
    arr[i] = -arr[i];
}
Console.WriteLine($"Converted:  {string.Join(" ", arr)} " );
Console.WriteLine($"sum of array elements: {arr.Sum()}");
﻿using System;
using System.Diagnostics;

class Program
{
    static void Main()
    {
        int a, x, t;
        double c, c1;

        Console.WriteLine("a * x * t + a = ?\n");

        Console.WriteLine("Input a: ");
        a = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Input x: ");
        x = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Input t: ");
        t = Convert.ToInt32(Console.ReadLine());

        int sum = a * x * t + a;
        Console.WriteLine($"\n{a} * {x} * {t} + {a} = " + sum);

        if (sum > 20)
        {
            Console.WriteLine("Bravo!\n");
        }

        else
        {
            Console.WriteLine("Bad...\n");
        }

        /*------------------------------------------*/

        Console.WriteLine("a * x * t * c = ?\n");

        Console.WriteLine("Input c: ");
        c = Convert.ToDouble(Console.ReadLine());

        double sum1 = a * x * t * c;
        Console.WriteLine($"\n{a} * {x} * {t} * {c} = " + sum1);

        /*------------------------------------------*/

        if (sum1 < 30)
        {
            Console.WriteLine("Bravo!\n");
        }

        else
        {
            Console.WriteLine("Bad...\n");
        }

        /*------------------------------------------*/

        Console.WriteLine("\na * (a + x) + c / t = ?\n");

        Console.WriteLine("Input c: ");
        c1 = Convert.ToDouble(Console.ReadLine());

        double sum2 = a * (a + x) + c1 / t;
        Console.WriteLine($"\n{a} * ({a} + {x}) + {c1} / {t} = " + sum2);

        if (sum2 < 20)
        {
            Console.WriteLine("Bravo!\n");
        }

        else
        {
            Console.WriteLine("Bad...\n");
        }

    }
}

﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Input x: ");
        double x = double.Parse(Console.ReadLine());
        double y = Math.Cos(Math.Log(x));
        Console.WriteLine($"y = cos(ln({x})) = {y}");

        Console.WriteLine("Input x: ");
        double x1 = double.Parse(Console.ReadLine());
        double y1 = Math.Atan(x1);
        Console.WriteLine($"y = | arctg x | = {y}");
    }
}
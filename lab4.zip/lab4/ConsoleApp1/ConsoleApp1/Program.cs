﻿using System.Text;
Console.OutputEncoding = Encoding.UTF8;
Console.WriteLine("Input start range");
float st = float.Parse(Console.ReadLine());
Console.WriteLine("Input end range");
float fn = float.Parse(Console.ReadLine());
int a, x, t;
double b, c;
Console.WriteLine("Input a");
a = int.Parse(Console.ReadLine());
Console.WriteLine("Input x");
x = int.Parse(Console.ReadLine());
Console.WriteLine("Input t");
t = int.Parse(Console.ReadLine());
Console.WriteLine("Input b");
b = int.Parse(Console.ReadLine());
Console.WriteLine("Input c");
c = int.Parse(Console.ReadLine());
int res1 = a * x * t + a;
double res2 = a + x / t + b - c;
double res3 = a * a + x + c * a - b / x;
if (st <= res1 && fn>=res1)
{
    Console.WriteLine("Вираз a * x * t + a входить в діапазон");
}
else
{
    Console.WriteLine("Вираз a * x * t + a не входить в діапазон");
}
if (st <= res2 && fn >= res2)
{
    Console.WriteLine("Вираз a + x / t + b - c входить в діапазон");
}
else
{
    Console.WriteLine("Вираз a + x / t + b - c не входить в діапазон");
}
 
if (st <= res3 && fn >= res3)
{
    Console.WriteLine("Вираз a * a + x + c * a - b / x входить в діапазон");
}
else
{
    Console.WriteLine("Вираз a * a + x + c * a - b / x не входить в діапазон");
}


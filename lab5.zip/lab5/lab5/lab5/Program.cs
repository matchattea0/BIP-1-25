﻿using System;
int a, b, c, a1, b1, gcd;
Console.WriteLine("Input num1");
a = int.Parse(Console.ReadLine());
Console.WriteLine("input num2");
b = int.Parse(Console.ReadLine());
c = 0;
gcd = 1;
a1 = a;
b1 = b;

while (b != 0)
{
    c = b;
    b = a % b;
    a = c;
}
Console.WriteLine("EVKLID METHOD");
Console.WriteLine($"GCD num1 and num2 = {c}" +
    $" \nLCM = {Math.Abs(a1*b1)/c}\n\n\n");


for (int i = 1; i <= Math.Min(a1, b1); i++)
    if (a1 % i == 0 && b1 % i == 0)
        gcd = i;

Console.WriteLine("\nFIND DIVISIOR METHOD");
Console.WriteLine($"GCD num1 and num2 = {gcd}\nLCM = {Math.Abs(a1 * b1) / c}");